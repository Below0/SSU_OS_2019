#ifndef DEVICES_PARTITION_H
#define DEVICES_PARTITION_H

struct blk_dev;

void partition_scan (struct blk_dev *);

#endif /* devices/partition.h */
